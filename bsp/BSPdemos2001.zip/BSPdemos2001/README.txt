
    BSP/CSG Technical Demos
    By Stan Melax  2001
    http://www.melax.com/

Greetings.  
Start by running one of the demo programs:

        MelaxBSP.EXE
        MelaxCSG.EXE

The help.txt and .cfg files has various 
instructions and config info/settings.
Try the 'b' key when running melaxcsg.exe
for some fun "geomod" boolean operations.

melaxcsg might crash once in a while if the boolean ops 
extend too far out.  try re-running.

Lindsay's nice artwork demo is not available with melaxcsg.exe
run melaxbsp.exe and hit the '4' key to load that one.  

the programs grab (and dont let go of the mouse).
these were compiled back in the windows 95 era.
These still seem to work on windows7 and windows8 
use alt-f4 or esc to quit, or task manager if necessary.

enjoy

Stan Melax

