some of the textures used in this demo may 
have come from a public domain texture pack.
here's the original readme/copyright 
information that came with the package:
--------------------------------------------


Thank you for downloading PhotoRealistic Texture Pack

---AUTHOR INFO---
Alias:	 BerneyBoy
Email:	 berneyboy@hotmail.com
Website: http://berneyboy.nav.to/
	 http://www.planetquake.com/wtf-q3a/
         http://www.planetquake.com/berneyboy/

---TEXTURE GTK INSTALLATION---
For people using GtkRadiant just unzip file into your Textures directory. That's it.
The textures should be available to you in the textures menu pop down in GtkRadiant.

---TEXTURE PACK INFO---
Title: PhotoRealistic
Filename: PhotoRealistic.zip
Version: 1.0
Release date: 03/10/03 (DD/MM/YY)
Theme/decor: urban environment & terra
Base: My Digital Camera and World Wide Web
Editor: Adobe Photoshop�
Textures info: I rigourously optimised to improve textures for map developer.
Total textures : 2051
Build time: A couple of months
The PhotoRealistic Texture Pack is organized into:

  NAME		Numbers of textures
- bricks	146
- concrete	74
- crate		40
- door		95
- floor		159
- frontage	99
- glassblock	19
- ground	72
- marble	76
- metal		172
- objets	54
- ornaments	73
- parquet	162
- road		40
- rock-stone	136
- roof		12
- sand		56
- terra		83
- tiles		21
- trim		42
- vegetal	69
- wall		132
- wallpaper	52
- window	60
- wood		107
---------	----
- TOTAL		2051

This is my Second released texture pack. 2000 Highly realistic stressed urban style textures
Most of the textures in this set are in photo/jpg format.

If you are using this PhotoRealistic texture pack, please inform me by e-mail where people can see your map. I will display your website in my Link section to find easily all maps done with PhotoRealistic texture.

Textures file are available for all these games: Clive Barker's Undying, Deus Ex,
Half-Life, Quake 3 Arena, Return to Castle Wolfenstein, Soldier of Fortune II,
Star Trek Voyager Elite Force, Star Wars JK II Jedi Outcas, Unreal Tournament / UT2003,
Wheel of Time. For a full explaination of each texture/shader please refer to my website.

---OTHER STUFF---
Don't hesitate to send me feedback! and please tell me if you reviewed it or put it on a server.

---Disclaimer---
Some images found in this archive were not created by me. These images were obtained from a number of sources on the Internet that labeled them as "freely distributable". Some of the authors of these graphics may not approve if the graphics are used commercially.

http://www.3dcafe.com/asp/textures.asp
http://www.grsites.com/textures/
http://www.amazing3d.com/services/textures.html
http://perso.wanadoo.fr/meteor_3d/AutreTextures.htm
http://www3.kannet.ne.jp/~f-works/gallery_bg.html
http://www.monitorstudios.com/bcloward/resources_textures.html
http://ww2.lafayette.edu/~reiterc/photo_symm/plr_index.html
http://www.pixelpoke.com/FREE%20PIXELS.html
http://www.grafik-welt.de/Download/DLTexturen.htm
http://infografiate.iespana.es/infografiate/
http://www.mayang.com/textures/
http://www.pixelpoke.com/ornament%20thumbnails.htm
http://www.jansdesigns.com/textures1.html
http://astronomy.swin.edu.au/~pbourke/texture/
http://www.thelimelite.net/html/textures1.shtml
http://www.webbied.com/3dtronic/
http://www.aaabackgrounds.com/
http://www.frenchtextures.com/
http://jonathanclark.com/textures/
http://www.art.net/~jeremy/photo/public_texture/
http://toob.bryce-alive.net/
http://astronomy.swin.edu.au/~pbourke/texture/
http://www.wolfiesden.com/golgotha/golgotha.html
http://mws.far.ru/textures/city.htm
http://perso.club-internet.fr/lemog/
http://www.imageafter.com/
http://invalide.gnougnou.com/textures.php
http://www.i-tex.de/gallery.htm
http://textures.forrest.cz/
http://www.cabinetdiscounters.com/corian/colors.html
http://www.ktn3d.com/downloadstextures-1.htm
http://digitalcraftsman.com/textureBin/textureBin.htm
http://www.uniquerenditions.com/TexturesZIPS2/NatureTextures1.htm
http://www.noctua-graphics.de/english/freetex_e.htm
http://www.levelsofdetail.com/
http://www.graysage.com/cg/BackDrops/Textures/

Original source images remain the property of their owners.

---COPYRIGHT/INFO---
.zip file copyright (c) 2003 BerneyBoy
All rights reserved.

THIS ZIP FILE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND. THE AUTHOR FURTHER DISCLAIMS ALL
IMPLIED WARRANTIES INCLUDING WITHOUT LIMITATION ANY IMPLIED WARRANTIES OF MERCHANTABILITY OR OF
FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK ARISING OUT OF THE USE OR PERFORMANCE OF THE
SOFTWARE AND DOCUMENTATION REMAINS WITH YOU.

IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DAMAGES WHATSOEVER (INCLUDING WITHOUT LIMITATION,
DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION, OR
OTHER PECUNIARY LOSS) ARISING OUT OF THE USE OF OR INABILITY TO USE THE SOFTWARE OR DOCUMENTATION
EVEN IF THE AUTHOR HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

PhotoRealistic texture pack is not made by or supported by id Software.

This texture pack may be electronically distributed only at NO CHARGE to the recipient in its
current state, MUST include this .txt file, and may NOT be modified IN ANY WAY. UNDER NO
CIRCUMSTANCES IS THIS FILES TO BE DISTRIBUTED ON CD-ROM WITHOUT PRIOR WRITTEN PERMISSION.