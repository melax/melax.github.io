game demo by Stan Melax - www.melax.com

Game "Teeter" see:  http://www.melax.com/teeter.html for latest information.


To get the latest version of microsoft directx goto:
  http://www.microsoft.com/directx
that may redirect you to: 
 http://www.gamesforwindows.com/en-US/AboutGFW/Pages/DirectX10.aspx  

When you ship a directx based product you can include something to update the user's computer to the latest directx.
That program "directx_aug2007_redist.exe" can be found here:

http://www.microsoft.com/downloads/details.aspx?FamilyID=2da43d38-db71-4c1b-bc6a-9b6652cd92a3&DisplayLang=en

